<?php return array (
  'section-form' => 'App\\Http\\Livewire\\SectionForm',
);