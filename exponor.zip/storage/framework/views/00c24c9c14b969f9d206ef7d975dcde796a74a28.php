<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h1 class="font-semibold text-xl text-gray-800 leading-tight">
            <div class="mt-8 text-4xl text-ligth">
                <b>EXPO</b>NOR 2022
            </div>
        </h1>
     <?php $__env->endSlot(); ?>

    <div class="py-12" style="margin-top: -230px">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="overflow-hidden ">
                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.welcome','data' => []] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-welcome'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
            </div>
        </div>
    </div>


    


<div class="flex justify-center items-center h-screen bg-section">
	<!--actual component start-->
	<div x-data="setup()" class="w-full max-w-7xl mx-auto sm:px-6 lg:px-8">
		<ul class="flex justify-center items-center my-4">
			<template x-for="(tab, index) in tabs" :key="index">
				<li class="cursor-pointer py-2 px-4 bg-ligth text-dark border-0 rounded-full m-4"
					:class="activeTab===index ? 'bg-dark text-ligth border-0' : ''" @click="activeTab = index"
					x-text="tab"></li>
			</template>
		</ul>

		<div class="w-full p-16 text-left mx-auto">
			<div x-show="activeTab===0" class="w-100">
                <h2 class="font-bold text-ligth text-2xl mb-4">CUENTANOS SOBRE TU EMPRESA</h2>
                <div>
                    <b>
                        <li class="text-dark">Desplaza la barra para el nivel de planta</li>
                        <li>
                            <input type="range">
                        </li>
                    </b>
                </div>
                <div>
                    <b>
                        <li class="text-dark">Desplaza la barra para identificar cuál es el nivel de tecnificación mantenimiento predictivo</li>
                    </b>
                </div>
                <div>
                    <b>
                        <li class="text-dark">¿Cuáles son las áreas de interes a desarrollar?</li>
                    </b>
                </div>
            </div>
			<div x-show="activeTab===1" class="w-100">
                <h2 class="font-bold text-2xl">SOBRE LOS PRODUCTO EN FERIA DE INTERES</h2>
                
            </div>
			<div x-show="activeTab===2" class="w-100">
                <h2 class="font-bold text-2xl">FINALMENTE QUEREMOS SABER COMO CONTACTARNOS CONTIGO</h2>
            </div>
		</div>
		
		<div class="flex gap-4 justify-center border-t p-4">
			<button
				class="py-2 px-4 border rounded-md border-blue-600 text-blue-600 cursor-pointer uppercase text-sm font-bold hover:bg-blue-500 hover:text-white hover:shadow"
				@click="activeTab--" x-show="activeTab>0"
				>Back</button>
			<button
				class="py-2 px-4 border rounded-md border-blue-600 text-blue-600 cursor-pointer uppercase text-sm font-bold hover:bg-blue-500 hover:text-white hover:shadow"
				@click="activeTab++" x-show="activeTab<tabs.length-1"
				>Next</button>
		</div>
	</div>
	<!--actual component end-->
</div>

<script>
	function setup() {
    return {
      activeTab: 0,
      tabs: [
          "EMPRESA",
          "PRODUCTOS",
          "CONTACTO",
      ]
    };
  };
</script>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('section-form')->html();
} elseif ($_instance->childHasBeenRendered('tKT8gqP')) {
    $componentId = $_instance->getRenderedChildComponentId('tKT8gqP');
    $componentTag = $_instance->getRenderedChildComponentTagName('tKT8gqP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tKT8gqP');
} else {
    $response = \Livewire\Livewire::mount('section-form');
    $html = $response->html();
    $_instance->logRenderedChild('tKT8gqP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\exponor\resources\views/welcome.blade.php ENDPATH**/ ?>